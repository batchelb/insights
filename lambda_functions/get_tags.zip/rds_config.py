#config file containing credentials for rds mysql instance
db_username = "batchelb"
db_password = "ISRocks!"
db_name = "insights"